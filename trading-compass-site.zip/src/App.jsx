import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1e1e2f] to-[#151522] text-white p-8">
      <h1 className="text-4xl font-bold text-center mb-4">Добро пожаловать в Trading Compass</h1>
      <p className="text-center text-gray-300">Обучение трейдингу и инвестициям для русскоговорящих за рубежом.</p>
    </div>
  );
}
